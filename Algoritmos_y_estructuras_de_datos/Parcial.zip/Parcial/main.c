///43.094.671_Atamiranda_Isaias
#include "parcial_header.h"

int main()
{

    //lote_prueba();
    //generar_archivos(2);
    //mostrar_prod_ok();
    //mostrar_arch_texto();
    //mostrar_stock();

    return 0;
}
