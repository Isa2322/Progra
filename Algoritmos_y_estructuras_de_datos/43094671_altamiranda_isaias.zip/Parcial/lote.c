#include "parcial_header.h"

int lote(t_lista *lista)
{
    t_arch vec[5];
    int i=3;
    FILE *pf;

    strcpy(vec[0].nomP,"messi");
    vec[0].nroP=1;

    strcpy(vec[1].nomP,"cristiano");
    vec[1].nroP=2;

    strcpy(vec[2].nomP,"neymar");
    vec[2].nroP=3;

    pf=fopen("participantes.dat","wb");
    if(!pf)
        return 1;

    fwrite(&i, sizeof(int), 1, pf);


    for(i=0; i<3; i++)
    {
        //poner_en_lista(lista, &vec[i], sizeof(t_arch));
        fwrite(&vec[i], sizeof(t_arch), 1, pf);
    }

    fclose(pf);

    return 3;
}
