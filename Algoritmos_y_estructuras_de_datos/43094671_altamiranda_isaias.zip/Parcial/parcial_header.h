//43094671_altamiranda_isaias
#ifndef PARCIAL_HEADER_H_INCLUDED
#define PARCIAL_HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#define ERROR_AL_CARGAR_PARTICIPANTES 1
#define ERROR_MEMORIA 2
#define LISTA_VACIA 3
#define ERROR_AL_CREAR_INFORME 4
#define TODO_BIEN 0

typedef struct
{
    int nroP;
    char nomP[25];
} t_arch;


typedef struct
{
    int numero_jugador;
    int posicion;
    int cant_rondas;
    char nombre[25];
} t_jugador;

typedef struct s_nodo
{
    void        *info;
    unsigned    tam_info;
    struct      s_nodo *sig;
} t_nodo;

typedef t_nodo *t_lista;



void crear_lista(t_lista *lista);
void vaciar_lista(t_lista *lista);
int cargar_participantes(t_lista *lista, int* cant_participantes);
int poner_en_lista(t_lista *lista, void *elem, unsigned tam_elem);
void cambiar_orden(t_lista *lista, int cant);
void jugar_rondas(t_lista *lista, int cant_participantes);
int informe_partida(t_lista *lista, int cant_jugadores, int n_ronda);

int lote(t_lista *lista);

#endif // PARCIAL_HEADER_H_INCLUDED
