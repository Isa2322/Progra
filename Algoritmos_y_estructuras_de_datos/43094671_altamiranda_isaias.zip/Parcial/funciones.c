//43094671_altamiranda_isaias
#include "parcial_header.h"


void crear_lista(t_lista *lista)
{
    *lista=NULL;
}


void vaciar_lista(t_lista *lista)
{
    t_nodo *aux;

    if(*lista==NULL)
        return;

    while(*lista)
    {
        aux=(*lista)->sig;

        if(aux == (*lista))
        {
            *lista=NULL;
        }
        else
        {
            (*lista) -> sig = aux -> sig;
        }
        free(aux ->info);
        free(aux);
    }
}


void cambiar_orden(t_lista *lista, int cant)
{
    t_nodo *aux=*lista;
    int desp, i;

    srand(time(NULL));
    desp=rand()%cant;

    for(i=desp; i>0; i--)
    {
        aux=aux->sig;
    }

    *lista=aux;
}


int poner_en_lista(t_lista *lista, void *elem, unsigned tam_elem)
{
    t_nodo *nue;

    nue=malloc(sizeof(t_nodo));

    if(!nue)
    {
        return ERROR_MEMORIA;
    }

    nue->info=malloc(tam_elem);

    if(!(nue->info))
    {
        free(nue);
        return ERROR_MEMORIA;
    }

    memcpy(nue->info, elem, tam_elem);
    nue->tam_info=tam_elem;

    if((*lista) ==NULL)
    {
        nue->sig=nue;
        (*lista)=nue;
        return TODO_BIEN;
    }

    nue->sig = (*lista)->sig;
    (*lista)->sig=nue;

    return TODO_BIEN;
}


void siguiente_lista(t_lista *lista)
{
    t_nodo *aux;

    aux=(*lista)->sig;
    (*lista)=aux;
}


///


int cargar_participantes(t_lista *lista, int* cant_participantes)
{
    FILE *pf;
    t_arch *aux;
    t_jugador jug;

    aux=malloc(sizeof(t_arch));
    if(aux==NULL)
        return ERROR_MEMORIA;

    pf=fopen("participantes.dat","rb");

    if(pf==NULL)
    {
        return ERROR_AL_CARGAR_PARTICIPANTES;
    }

    fread(cant_participantes, sizeof(int), 1, pf);

    while(!feof(pf))
    {
        fread(aux, sizeof(t_arch), 1, pf);
        jug.numero_jugador=aux->nroP;
        strcpy(jug.nombre, aux->nomP);

        jug.cant_rondas=0;
        jug.posicion=-1; ///para poder saltear el jugador que perdio mas adelante

        if(jug.numero_jugador>1)
        {
            cambiar_orden(lista, *cant_participantes);
        }
        poner_en_lista(lista, &jug, sizeof(t_jugador));
    }


    free(aux);
    fclose(pf);

    return TODO_BIEN;
}


void jugar_rondas(t_lista *lista, int cant_participantes)
{
    t_jugador act;
    int i, dado, max_dado=7, pos=cant_participantes;

    while(pos>1)
    {
        for(i=0; i<cant_participantes; i++)
        {
            memcpy(&act, (*lista)->info, sizeof(t_jugador));

            while(act.posicion != -1)
            {
                siguiente_lista(lista);
            }

            printf("Es el turno de %s, toca una tecla para tirar el dado\n\n\n",act.nombre);
            system("pause");
            system("cls");
            do
            {
                srand(time(NULL));
                dado=rand()%max_dado;
            }
            while(dado<1 || dado>6);

            printf("%s, sacaste un: %d\n",act.nombre, dado);

            if(dado==5 && pos>1)
            {
                printf("perdiste :( \n quedaste en posicion: %d\n",pos);
                act.posicion=pos;
                pos--;
            }
            else
            {
                printf("seguis en juego\n");
            }

            system("pause");
            system("cls");

            act.cant_rondas++;
            memcpy((*lista)->info, &act, sizeof(t_jugador));
            siguiente_lista(lista);
        }

    }
    system("cls");
    printf("fin de la partida");

    for(i=0; i<cant_participantes; i++)
    {
        memcpy(&act, (*lista)->info, sizeof(t_jugador));

        if(act.posicion == -1)
        {
            act.posicion=1;
            memcpy((*lista)->info, &lista, sizeof(t_jugador));
        }
    }

}


int informe_partida(t_lista *lista, int cant_jugadores, int n_ronda)
{
    int i;
    t_jugador act, ganador;
    FILE *pf;
    char nom_arch[17];

    sprintf(nom_arch, "partida %d", n_ronda);

    pf=fopen(nom_arch,"wt");
    if(!pf)
    {
        return ERROR_AL_CREAR_INFORME;
    }

    fprintf(pf, "PARTIDA Nro.:%d\n",n_ronda);

    for(i=cant_jugadores; i>0; i--)
    {
        memcpy(&act, (*lista)->info, sizeof(t_jugador));

        if(act.posicion == 1)
        {
            ganador=act;
        }
        else
        {
            fprintf(pf, "Posicion: %d - Cantidad de rondas jugadas: %d - JugadorNro.: %d - Nombre: %s\n",act.posicion, act.cant_rondas, act.numero_jugador, act.nombre);
            printf("Posicion: %d - Cantidad de rondas jugadas: %d - JugadorNro.: %d - Nombre: %s\n",act.posicion, act.cant_rondas, act.numero_jugador, act.nombre);
        }
    }

    fprintf(pf,"GANADOR - Jugador Nro.: %d - Nombre: %s\n",ganador.numero_jugador, ganador.nombre);
    printf("GANADOR - Jugador Nro.: %d - Nombre: %s\n",ganador.numero_jugador, ganador.nombre);

    fprintf(pf,"Cantidad total de rondas jugadas en esta partida: %d",ganador.cant_rondas);
    printf("Cantidad total de rondas jugadas en esta partida: %d",ganador.cant_rondas);

    fclose(pf);

    return TODO_BIEN;
}










///
/*
void crear_lista(t_lista *lista)
{
    *lista=NULL;
}

///

void vaciar_lista(t_lista *lista)
{
    t_nodo *aux;

    if(*lista==NULL)
        return;

    while(*lista)
    {
        aux=(*lista)->sig;

        if(aux==(*lista))
        {
            *lista=NULL;
        }
        else
        {
            (*lista)->sig=aux->sig;
        }

        free(aux->info);
        free(aux);
    }
}

///

int poner_sig(t_lista *lista, const void *elem, unsigned tam_elem) //pongo un nuevo nodo a continuacion del que esta apuntado
{
    t_nodo *nue;

    nue=malloc(sizeof(t_nodo));

    if(!nue)
    {
        return ERROR_DE_MEMORIA;
    }

    nue->info=malloc(tam_elem);

    if(!(nue->info))
    {
        free(nue);
        return ERROR_DE_MEMORIA;
    }

    memcpy(nue->info, elem, tam_elem);
    nue->tam_info=tam_elem;

    if((*lista) == NULL)
    {
        nue->sig=nue;
        (*lista)=nue;
        return TODO_OK;
    }

    nue->sig=(*lista)->sig;
    (*lista)->sig=nue;

    return TODO_OK;
}

///

int randomizer(t_lista *lista, int num) //lo que hago aca es avanzar un numero n de nodos y luego declarar ese como el primero
{
    if(*lista == NULL)
        return ERROR_DE_MEMORIA;

    t_nodo *aux;

    int i, j;

    srand(time(NULL));
    j=rand()%num;

    aux=*lista;

    for(i=0; i<j; i++)
    {
        aux=aux->sig;
    }

    *lista=aux;

    return TODO_OK;
}

///

void sig_lista(t_lista *lista)
{
    t_nodo *aux;

    aux=(*lista)->sig;
    (*lista)=aux;
}

///

int carga_config(int* rounds, int* cant_rounds)
{
    FILE *config;
    config=fopen("config.txt","rt");
    if(!config)
    {
        puts("Error al cargar las configuraciones");
        return ERROR_CONFIG;
    }

    fscanf(config,"Rounds: %d\nTiempo por round: %d",rounds, cant_rounds);

    fclose(config);


    if((*rounds)<4 || (*rounds)>7)
    {
        puts("Error al cargar las configuraciones");
        return ERROR_CONFIG;
    }

    return TODO_OK;
}

///

int carga_participantes(t_lista *lista,int* n_participantes)
{
    int i;
    jugador nuevo_j;

    do
    {
        printf("Ingrese la cantidad de participantes: ");
        scanf("%d",n_participantes);
        fflush(stdin);
        system("cls");
    }
    while((*n_participantes)<1); ///como no tengo un limite de participantes no tengo como validar que no sea una letra

    system("cls");

    for(i=0; i<(*n_participantes); i++)
    {
        printf("Ingrese el nombre del participante %d: ", i + 1);
        scanf("%s", nuevo_j.nombre);
        fflush(stdin);
        nuevo_j.puntos=0;

        if(i>1)
        {
            randomizer(lista,i+1);
        }

        poner_sig(lista, &nuevo_j, sizeof(jugador));

        system("cls");
    }


    return TODO_OK;
}

///

void menu(char *opcion)
{
    printf("\nSelecione una opcion....\n");
    printf("\n[A]Jugar\n");
    printf("\n[B]Salir\n");

    do
    {
        scanf("%c",opcion);
        fflush(stdin);
        (*opcion)=toupper(*opcion);
    }
    while((*opcion)!='A' && (*opcion)!='B');

    system("cls");

}

///

void dificultad(int *dif)
{
    *(dif)=0;
    do
    {
        printf("Ingrese el nivel de dificultad \n(1)facil\n(2)medio\n(3)dificil: ");
        fflush(stdin);
        scanf("%d",dif);
        fflush(stdin);
        system("cls");
    }
    while((*dif)<1 || (*dif)>3);
}

///

void mezclar_preguntas(Pregunta preguntas[], int num_preguntas)
{
    int i, j;
    Pregunta aux;

    srand(time(0));

    for(i=(num_preguntas-1); i>0; i--)
    {
        j=rand()%(i);

        aux=preguntas[i];
        preguntas[i]=preguntas[j];
        preguntas[j]=aux;
    }
}

///

void jugarRondas(int n_participantes,int tiempo_ronda,int rondas,int nivel_dif, t_lista *lista, Pregunta preguntas[])
{
    int r, num_preguntas=0, j, hay_resp=0, tiempo_respuesta, i;
    char respuesta;
    jugador *act;
    Pregunta *pregunta;
    clock_t start_time;

    act=malloc(sizeof(jugador));

    if(!act)
    {
        return;
    }

    if (!obtener_preguntas(nivel_dif, preguntas, &num_preguntas))
    {
        printf("No se pudieron obtener las preguntas\n");
        return;
    }

    mezclar_preguntas(preguntas, num_preguntas);
/// nota: las fotos de los lotes de prueba corresponden al orden de las preguntas por defecto
/// para comprobar que las fotos de los lotes de prueba sean correctos se puede comentar
/// la funcion mezclar_preguntas para conseguir los mismos resultados que en el lote, ya que es
/// no es absolutamente necesaria, sin embargo, para jugar es mejor dejar la funcion tal como est�

    printf("Se jugaran %d rondas de %d segundos cada una\nEl orden de los jugadores sera:\n", rondas, tiempo_ronda);

    for(i=0; i<n_participantes; i++)
    {
        memcpy(act, (*lista)->info, sizeof(jugador));
        printf("%d) %s\n",i+1,act->nombre);
        sig_lista(lista);
    }

    system("pause");
    system("cls");


    for(i=0; i<n_participantes; i++)
    {
        memcpy(act, (*lista)->info, sizeof(jugador));
        printf("Turno de %s.\n Estas listo/a?\n", act->nombre);
        system("pause");
        system("cls");
        fflush(stdin);

        for(r=0; r<rondas; r++)
        {
            hay_resp=0;
            pregunta=&preguntas[r];

            printf("Pregunta: %s\n", pregunta->pregunta);


            for(j=0; j < pregunta->num_opciones; j++)
            {
                printf("%s\n", pregunta->opciones[j]);
            }

            start_time=clock();

            respuesta='\n';
            do
            {
                if(kbhit())
                    respuesta=getchar();

                fflush(stdin);
                if(respuesta<101 && respuesta>96) ///abcd minuscula
                {
                    respuesta=toupper(respuesta); ///Paso a mayuscula
                    hay_resp=1;
                }
                else
                {
                    if(respuesta>64 && respuesta<69)
                        hay_resp=1;
                }

            }
            while(((clock()-start_time)/CLOCKS_PER_SEC)<tiempo_ronda && hay_resp==0);

            tiempo_respuesta=(clock()-start_time)/CLOCKS_PER_SEC;

            if(hay_resp==0)
            {
                printf("\nTiempo agotado. Siguiente pregunta...\n\n");
                respuesta='\n'; // Sin respuesta
                tiempo_respuesta=tiempo_ronda;
            }

            act->respuestas[r]=respuesta;
            act->tiempo[r]=tiempo_respuesta;
        }

        memcpy((*lista)->info, act, sizeof(jugador));
        sig_lista(lista);

        system("pause");
        system("cls");
    }
}

///

int calcular_puntaje(t_lista *lista, Pregunta preguntas[], int rondas, int n_participantes)
{
    int i, j, min, empate;
    jugador *act;
    char resp_part, resp_cor;

    act=malloc(sizeof(jugador));
    if(!act)
    {
        puts("No se pudo calcular los puntajes");
        return ERROR_DE_MEMORIA;
    }

    for(i=0; i<rondas; i++)
    {
        min=-1;
        empate=0;
        for(j=0; j<n_participantes; j++)
        {
            memcpy(act, (*lista)->info, sizeof(jugador));

            resp_part=act->respuestas[i];
            resp_cor=preguntas[i].respcorrecta;


            if(toupper(resp_part) == toupper(resp_cor))
            {
                if((act)->tiempo[i] == min)
                {
                    empate=1;
                }

                if(min==-1)
                {
                    min=act->tiempo[i];
                }

                if((act)->tiempo[i] < min)
                {
                    min=act->tiempo[i];
                    empate=0;
                }

            }

            sig_lista(lista);
        }

        for(j=0; j<n_participantes; j++)
        {
            memcpy(act, (*lista)->info, sizeof(jugador));

            resp_part=act->respuestas[i];
            resp_cor=preguntas[i].respcorrecta;

            if(toupper(resp_part) == toupper(resp_cor))
            {
                if((act)->tiempo[i] == min)
                {
                    if(empate==1)
                    {
                        act->puntos+=2;
                        act->puntos_por_pregunta[i]=2;
                    }
                    else
                    {
                        act->puntos+=3;
                        act->puntos_por_pregunta[i]=3;
                    }
                }
                else
                {
                    act->puntos+=1;
                    act->puntos_por_pregunta[i]=1;
                }
            }
            else
            {
                if(resp_part != '\n')
                {
                    act->puntos-=2;
                    act->puntos_por_pregunta[i]= -2;
                }
                else
                    act->puntos_por_pregunta[i]=0;
            }
            memcpy((*lista)->info, act, sizeof(jugador));
            sig_lista(lista);
        }
    }

    free(act);
    return TODO_OK;

}

///

int informe_arch_ganador(t_lista *lista, Pregunta preguntas[], int rondas, int n_participantes)
{
    int i, j, empate=0, max;
    char str[35];
    jugador *act;
    FILE *pf;
    time_t rawtime;
    struct tm *timeinfo;


    time(&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(str, 35, "informe-juego_%Y-%m-%d-%H-%M.txt", timeinfo);

    pf=fopen(str,"wt");

    if(!pf)
    {
        puts("Error al crear un informe");
        return ERROR_INFORME;
    }


    for(i=0; i<rondas; i++)
    {
        fprintf(pf,"Pregunta: %s\nRespuesta correcta: %c\n\n",preguntas[i].pregunta, toupper(preguntas[i].respcorrecta));

        for(j=0; j<n_participantes; j++)
        {
            act=(*lista)->info;
            fprintf(pf,"Participante: %s\n\tRespuesta: %c\n\tPuntos: %d\n\tTiempo: %d\n\n"
                    ,act->nombre, act->respuestas[i], act->puntos_por_pregunta[i], act->tiempo[i]);
            sig_lista(lista);
        }

        fprintf(pf,"\n");
    }

    fprintf(pf,"\n\n\nPuntaje Total\n");

    for(i=0; i<n_participantes; i++)
    {
        act=(*lista)->info;
        fprintf(pf,"%s: %d Puntos\n",act->nombre, act->puntos);
        sig_lista(lista);
    }

    for(i=0; i<n_participantes; i++)
    {
        act=(*lista)->info;

        if(act->puntos == max && i!=0)
        {
            empate=1;
        }

        if(i == 0 || act->puntos > max)
        {
            max=act->puntos;
            empate=0;
        }

        sig_lista(lista);
    }

    fprintf(pf,"\n\n");

    if(max<=0)
    {
        printf("no hay ganadores\n\n");
        fprintf(pf,"no hay ganadores");
        fclose(pf);
        system("pause");
        system("cls");

        return TODO_OK;
    }
    if(empate == 0)
    {
        for(i=0; i<n_participantes; i++)
        {
            act=(*lista)->info;

            if(act->puntos == max)
            {
                printf("El/la ganador/a es: %s con %d puntos\n\n",act->nombre, max);
                fprintf(pf,"El/la ganador/a es: %s con %d puntos\n\n",act->nombre, max);
            }

            sig_lista(lista);
        }
    }
    else
    {
        printf("Los ganadores son: \n");
        fprintf(pf,"Los ganadores son: \n");

        for(i=0; i<n_participantes; i++)
        {
            act=(*lista)->info;

            if(act->puntos == max)
            {
                printf("%s con %d puntos\n\n",act->nombre, max);
                fprintf(pf,"%s con %d puntos\n\n",act->nombre, max);
            }

            sig_lista(lista);
        }
    }

    fclose(pf);

    system("pause");
    system("cls");

    return TODO_OK;
}
*/
