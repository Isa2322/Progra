//43094671_altamiranda_isaias
#include "parcial_header.h"

int main()
{
    t_lista lista;
    int cant_participantes, de_nuevo, rondas=0;

    crear_lista(&lista);

    cant_participantes=lote(&lista);

    do
    {
        cargar_participantes(&lista, &cant_participantes);

        jugar_rondas(&lista, cant_participantes);

        rondas++;

        informe_partida(&lista, cant_participantes, rondas);

        printf("jugar de nuevo? \n 1=si");
        scanf("%d",&de_nuevo);

        vaciar_lista(&lista);

    }while(de_nuevo==1);

    return 0;
}
