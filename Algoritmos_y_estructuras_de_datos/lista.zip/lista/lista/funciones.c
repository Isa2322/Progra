#include "header_lista.h"


void crear_lista(t_lista *lista)
{
    *lista=NULL;
}


////////////////////////////////////////////////////


int lista_vacia(const t_lista *lista)
{
    return *lista == NULL;
}


////////////////////////////////////////////////////


int lista_llena(const t_lista *lista, unsigned tam_elem)
{
    t_nodo *aux;
    void *info;

    aux=malloc(sizeof(t_nodo));

    if(aux==NULL)
    {
        return SIN_MEM;
    }

    info=malloc(tam_elem);

    if(info == NULL)
    {
        free(aux);
        return SIN_MEM;
    }

    free(aux);
    free(info);

    return TODO_OK;
}


////////////////////////////////////////////////////


void vaciar_lista(t_lista *lista)
{
    t_nodo *aux;

    while(*lista!=NULL)
    {
        aux=*lista;
        *lista=aux->sig;
        free(aux->info);
        free(aux);
    }
}


////////////////////////////////////////////////////


int poner_al_inicio(t_lista *lista, void* info_nue, unsigned tam_info_nue)
{
    t_nodo *nue=*lista;

    nue=malloc(sizeof(t_nodo));

    if(nue==NULL)
    {
        return SIN_MEM;
    }

    nue->info=malloc(tam_info_nue);

    if(nue->info==NULL)
    {
        free(nue);
        return SIN_MEM;
    }

    memcpy(nue->info, info_nue, tam_info_nue);
    nue->tam_info=tam_info_nue;
    nue->sig=*lista;
    *lista=nue;

    return TODO_OK;
}


////////////////////////////////////////////////////


int poner_al_final(t_lista *lista, void* info_nue, unsigned tam_info_nue)
{
    t_nodo *nue;

    while(*lista!=NULL)
    {
        lista=&(*lista)->sig; //PREGUNTAR!!!!!
    }

    nue=malloc(sizeof(t_nodo));

    if(nue==NULL)
    {
        return SIN_MEM;
    }

    nue->info=malloc(tam_info_nue);

    if(nue->info==NULL)
    {
        free(nue);
        return SIN_MEM;
    }

    memcpy(nue->info, info_nue, tam_info_nue);
    nue->tam_info=tam_info_nue;
    nue->sig=NULL;
    *lista=nue;


    return TODO_OK;
}


////////////////////////////////////////////////////


int sacar_primero(t_lista *lista, void *elem, unsigned tam_elem)
{
    t_nodo *aux;

    aux=*lista;

    if(aux==NULL)
        return VACIA;

    *lista=aux->sig;

    memcpy(elem, aux->info, MINIMO(tam_elem, aux->tam_info));
    free(aux->info);
    free(aux);

    return TODO_OK;
}


////////////////////////////////////////////////////


int sacar_ultimo(t_lista *lista, void *elem, unsigned tam_elem)
{
    if(*lista==NULL)
        return VACIA;

    while((*lista)->sig!=NULL)
    {
        lista=&(*lista)->sig;
    }

    memcpy(elem, (*lista)->info, MINIMO(tam_elem, (*lista)->tam_info));

    free((*lista)->info);
    free(*lista);
    *lista=NULL;

    return TODO_OK;
}


////////////////////////////////////////////////////


int ver_primero(t_lista *lista, void *elem, unsigned tam_elem)
{
    if(*lista==NULL)
        return VACIA;

    memcpy(elem, (*lista)->info, MINIMO(tam_elem, (*lista)->tam_info));

    return TODO_OK;

}


////////////////////////////////////////////////////


int poner_luego_de_n(t_lista *lista, void* info_nue, unsigned tam_info_nue, int parametro)
{
    t_nodo *nue;

    while(*lista!=NULL && parametro>0)
    {
        lista=&(*lista)->sig;
        parametro--;
    }

    if(parametro>0)
        return INSUFICIENTES_ELEMENTOS;

    nue=malloc(sizeof(t_nodo));

    if(nue==NULL)
    {
        return SIN_MEM;
    }

    nue->info=malloc(tam_info_nue);

    if(nue->info==NULL)
    {
        free(nue);
        return SIN_MEM;
    }

    memcpy(nue->info, info_nue, tam_info_nue);
    nue->tam_info=tam_info_nue;
    nue->sig=(*lista)->sig;
    (*lista)->sig=nue;

    return TODO_OK;
}


////////////////////////////////////////////////////


int sacar_siguiente_a_n(t_lista *lista, void *elem, unsigned tam_elem, int parametro)
{
    t_lista *aux=lista;

    if(*lista==NULL)
        return VACIA;

    while((*lista)->sig!=NULL && parametro>0)
    {
        lista=&(*lista)->sig;
        parametro--;
    }

    if(parametro>0)
        return INSUFICIENTES_ELEMENTOS;

    memcpy(elem, (*lista)->info, MINIMO(tam_elem, (*lista)->tam_info));

    *aux=(*lista)->sig;

    (*lista)->sig=(*aux)->sig;



    free((*lista)->info);
    free(*lista);
    *lista=NULL;

    return TODO_OK;
}
