#ifndef HEADER_LISTA_H_INCLUDED
#define HEADER_LISTA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIN_MEM 1
#define VACIA 2
#define INSUFICIENTES_ELEMENTOS 3
#define TODO_OK 0
#define MINIMO( X , Y ) ((X)<(Y)?(X):(Y))

typedef struct s_nodo
{
    void *info;
    unsigned tam_info;
    struct s_nodo *sig;
} t_nodo;

typedef t_nodo *t_lista;


void crear_lista(t_lista *lista);
int lista_vacia(const t_lista *lista);
int lista_llena(const t_lista *lista, unsigned tam_elem);
void vaciar_lista(t_lista *lista);
int poner_al_inicio(t_lista *lista, void* info_nue, unsigned tam_info_nue);
int poner_al_final(t_lista *lista, void* info_nue, unsigned tam_info_nue);
int sacar_primero(t_lista *lista, void *elem, unsigned tam_elem);
int sacar_ultimo(t_lista *lista, void *elem, unsigned tam_elem);


#endif // HEADER_LISTA_H_INCLUDED
