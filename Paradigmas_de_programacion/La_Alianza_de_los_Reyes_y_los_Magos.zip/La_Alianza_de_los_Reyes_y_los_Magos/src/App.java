
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		MensajeroMagico m = new MensajeroMagico();
		
		m.EnviarMensaje("Super");
		m.EnviarMensaje("Massive");
		m.EnviarMensaje("Black");
		m.EnviarMensaje("Holes");

		
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		
		m.EnviarMensajeAltaPrioridad("MLV");
		m.EnviarMensajeAltaPrioridad("1724");
		m.EnviarMensajeAltaPrioridad("Soho");
		m.EnviarMensajeAltaPrioridad("Al parecer todo ha sido una trampa");
		
		
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		
		
		m.EnviarMensaje("come");
		m.EnviarMensajeAltaPrioridad("has");
		m.EnviarMensaje("and passed");
		m.EnviarMensajeAltaPrioridad("Summer");
		
		
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		System.out.println(m.RecibirMensaje());
		*/
		
		/*
		String[] lista1 = {
		    "Dark Hole",
		    "Monster Reborn",
		    "Pot of Greed",
		    "Mystical Space Typhoon",
		    "Swords of Revealing Light",
		    "Heavy Storm",
		    "Graceful Charity",
		    "Book of Moon",
		    "Raigeki",
		    "Polymerization",
		    "Magical Mallet",
		    "Scapegoat",
		    "Fissure",
		    "Change of Heart",
		    "Lightning Vortex",
		    "Terraforming",
		    "Enemy Controller",
		    "Soul Exchange"
		};

		String[] lista2 = {
		    "Mystical Space Typhoon",
		    "Raigeki",
		    "Monster Reborn",
		    "Dark Hole",
		    "Premature Burial",
		    "Pot of Avarice",
		    "Snatch Steal",
		    "Brain Control",
		    "Polymerization",
		    "Twin Twisters",
		    "Dark Magic Attack",
		    "Card Destruction",
		    "Limiter Removal",
		    "Megamorph",
		    "Mirror Force",
		    "Harpie's Feather Duster",
		    "Lightning Vortex",
		    "Reinforcement of the Army"
		};
		
		
		Magos mago1 = new Magos(lista1);
		Magos mago2 = new Magos(lista2);
		
		System.out.println(mago1.CompararHechizos(mago2));
		*/
	

	}

}
