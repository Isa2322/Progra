package ar.edu.unlam.pb2.excepciones;

public class ClienteDuplicadoException{

}
