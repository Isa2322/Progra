package ar.edu.unlam.pb2.enums;

public enum Colores {
	CAOBA, CEDRO, ROBLE_OSCURO
}
