package ar.edu.unlam.pb2.enums;

public enum Materiales {
	PLASTICO, YESO, RECINA
}
